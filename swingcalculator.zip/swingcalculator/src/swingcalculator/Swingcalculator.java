package swingcalculator;
import javax.swing.*;
public class Swingcalculator {
    public static void main(String[] args) {
        new Calculator();
    }
    
}
